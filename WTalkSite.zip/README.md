# 🌐 WTalk - Global Chat Platform

WTalk is a worldwide chat platform where users can connect with strangers based on gender and country flag. It blocks NSFW content, racist speech, and sensitive data like phone numbers or bank details.

## 🚀 Features
- Realtime open chat UI
- Gender and country flag selector
- NSFW word filter
- Anti-racism and anti-spam rules
- Blocks phone numbers, emails, and sensitive info

## 🛡️ Rules
- ❌ No NSFW content
- ❌ No racism or hate speech
- ❌ No personal info (phone, email, bank details)
- ✅ Friendly, global conversations only

## 📜 License
This project is licensed under the [MIT License](LICENSE).